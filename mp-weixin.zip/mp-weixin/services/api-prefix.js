"use strict";console.log("ENV_NAME","test");exports.baseUrl="https://test-weixin-api.simon.com/";
