"use strict";const e=require("../../common/vendor.js"),n=e.defineComponent({__name:"index",setup(n){const t=e.ref("Hello");return(n,o)=>({a:e.t(t.value)})}});wx.createPage(n);
